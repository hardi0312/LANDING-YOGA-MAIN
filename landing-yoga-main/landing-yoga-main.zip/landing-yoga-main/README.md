# 🧘 Responsive Yoga Website

Yoga landing page provides information about the best yoga and health, social media links, business address, and subscribe to follow news from health with yoga.

And you can get information about the store address and social media.

## What List Features
- Responsive Yoga Website Design Using HTML CSS & JavaScript
- Contains animations when scrolling.
- Smooth scrolling in each section.
- Includes a dark & light theme.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

<b>DIFFICULTY</b>
`Medium`

💙 Thanks to see more my portfolio and like this.

![preview img](/preview.png)
